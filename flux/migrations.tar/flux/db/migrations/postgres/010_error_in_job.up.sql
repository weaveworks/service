ALTER TABLE jobs
  ADD error jsonb default NULL;
