ALTER TABLE jobs
  ADD result jsonb default NULL;
