ALTER TABLE jobs
  ADD result string;
