DROP TABLE release_jobs;
