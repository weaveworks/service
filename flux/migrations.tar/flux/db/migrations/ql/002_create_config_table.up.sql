CREATE TABLE IF NOT EXISTS config
  (instance string NOT NULL,
   config   string NOT NULL,
   stamp    time NOT NULL)
