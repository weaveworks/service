DROP TABLE history;
