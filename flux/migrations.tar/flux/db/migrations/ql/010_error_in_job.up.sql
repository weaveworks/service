ALTER TABLE jobs
  ADD error string default NULL;
